// Maloney Khim and Hannah Kim
//
// Description of the project:
//
// A zen interactive animation, to be a part of Concordia University's Zen dens.
// Concordia University has multiple peaceful zen rooms for students to relax, hang out with other students and provides wellness resources.
// We wanted to create a piece that would incorporate and be included within the zones. Creating a fun, interactive, peaceful piece for other students.
//
// P.S sometimes the fishes take time to load, refresh the page and it will start to move and mouse press to make ripples with sound effect + music.
//


// sfx, music
var song = "waves.ogg";
var sound = "drip.ogg";



//ripples
var x;
var y;
var lightWater = [195,238,238];
var darkWater = [106,213,213];
var radius = 8;
var water = [23,100,108];


//koi gif
let fish1;
let fish2;
let fish3;
let waterlilyLeaf1;
let waterlilyLeaf2;
let posX = -500;
let posY = 0;


function preload(){

//music, sfx
song = loadSound('assets/sounds/waves.ogg');
sound = loadSound('assets/sounds/drip.ogg');

//koi fish
fish1=loadImage("koi-fish1.gif");
fish2=loadImage("koi-fish2.gif");
fish3=loadImage("koi-fish3.gif");
waterlilyLeaf1=loadImage("waterlily1.png");
waterlilyLeaf2=loadImage("waterlily2.png");

}

function setup() {

  angleMode(DEGREES);
  createCanvas(windowWidth, windowHeight);

  //bg music
  song.play();
  song.setVolume(0.5);
  song.loop();

  //drip sfx
  sound.play();
  sound.setVolume(0.8);

}


function draw() {

background(water);


//text
textSize(150);
text("Click to play with water!", 200, 3000);

//koi fish gif
tint(255, 127);
image(fish2, posX, 1000, 1800, 900);
noTint();
image(fish1, 4000-posX, 55, 2000, 1000);
image(fish3, 5000-posX, 2200, 2055, 1011);

if(posX > width || posY > height){
  posX=-500;
  posY=0;
}
else{
  posX+=10;
  posY-=3;
}


// waterlilies
image(waterlilyLeaf1, 1000, 2000, 1000, 800);
image(waterlilyLeaf2, 4000, 500, 1031, 931);


//water ripples
  noFill();
  frameRate(10); // frames for the ripples
  strokeWeight((windowWidth/200)+(random(5 +(mouseY-mouseX)/10)));
  if (radius < windowWidth)  {
  color = (lightWater,(windowWidth/1-radius));
	color = (darkWater,(windowWidth/3-radius));

  stroke(darkWater);
  ellipse(x, y, radius-8, radius-8);
  ellipse(x, y, radius+8, radius+8);

  radius += (random(((mouseX)/10), ((windowWidth-mouseX)/10)));
  stroke(lightWater);
  ellipse(x, y, radius, radius);
  }

  // Round rock border
    fill(186, 202, 204);
    noStroke();
    var diameter = 500;

    for (var i=0; i< width/diameter; i=i+1) {
      ellipse(diameter/2 + i * diameter, windowHeight, diameter,
      diameter);
  }

  for (var i=0; i< width/diameter; i=i+1) {
    ellipse(diameter/2 + i * diameter,0, diameter,
    diameter);
}
}


function mousePressed() {

  background(water);
  radius = 3;
  x = mouseX;
	y = mouseY;
  draw();

  if (sound.isPlaying() ) {
  sound.stop();
  background(255);
} else {
  sound.play();
  background(0);
}
}

//
// RESOURCES/CREDIT:
// https://happycoding.io/examples/p5js/input/mouse-ripple
// https://editor.p5js.org/Jennybkowalski/sketches/ByFRVsstX
// https://p5js.org/examples/sound-preload-soundfile.html
// https://nycdoe-cs4all.github.io/units/3/lessons/lesson_5.2
// https://p5js.org/reference/#/p5.SoundFile
// https://www.youtube.com/watch?v=BwJB95-cdRI&ab_channel=soungungLee
// https://www.youtube.com/watch?v=Pm7o-aPuEYk&ab_channel=ComputingMasterclass
// https://editor.p5js.org/MSingh10/sketches/SH-7tEzx-
