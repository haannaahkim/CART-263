
let clickCounter = 0
let myVar = 0
let h = 500;
let w = 500;

"use strict";

function setup() {
 createCanvas(w,h);
 background(73,103,120);
}

function mouseClicked(){
  clickCounter++;
  print(clickCounter);
}

function draw() {
  if (mouseIsPressed){
    fill (255, 0, 0);
    noStroke();
    ellipse (h/2, w/2, 250, 250);
  } else if(keyIsPressed) {
    fill(0, 160, 80);
    noStroke();
    ellipse(100, 100, 250, 250);
  } else if(clickCounter >= 3 && clickCounter <=5) {
    background(37, 11, 227);
  } else {
    background(73, 103, 120);
  }
}
